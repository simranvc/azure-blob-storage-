import express from 'express';
const app = express();
import bodyParser from 'body-parser';
import fs from 'fs';
import environment from '../environment';
import cors from 'cors';
import path from 'path';

import multer from 'multer';
const inMemoryStorage = multer.memoryStorage();
const singleFileUpload = multer({ storage: inMemoryStorage });
import azureStorage from 'azure-storage';
import getStream from 'into-stream';
import { log } from 'util';
 
// getting application environment
const env = process.env.NODE_ENV;
// console.log('env :', env);
// return false
// getting application config based on environment
const envConfig = environment[env];

// console.log('envConfig :', envConfig);
// return false
// setting port value
const port = envConfig.port || 3000;

app.use(bodyParser.json({
    limit: '50mb'
}));
app.use(bodyParser.urlencoded({
    limit: '50mb',
    extended: true
}));
app.use(express.static(path.join(__dirname, '/public')));
app.use(cors());


var azureStorageConfig = {
    accountName: "edexabackup",
    accountKey: "CK4r5uFRsmw1gchZXyJ70k3yl1JrDqYsUY1lyblC03ruBh4hFk4RN2NpXeJCWHTFWuL9j+cVMHz4bj0SX+3hsQ==",
    blobURL: "https://edexabackup.blob.core.windows.net/",
    containerName: "archive-api"
};
 

async function storeInMultiplePart(directoryPath, file) {

    // console.log("file responce :------",file);
    // return false
    
    return new Promise((resolve, reject) => {
      
        var blobName = getBlobName(file.originalname);
        // console.log("sadasd name:------",blobName);
        
        var stream = getStream(file.buffer);

        // console.log("stream : ---------",stream);
        // return false
        // var stream = file.buffer;

        var streamLength = Math.ceil(file.buffer.length / 3);

        console.log("streamLength",streamLength);
        //  return false
        var promises = [];
        var i = 1;
    
        // var exe = file.originalname.split('.');
        // var name = path.basename(file.originalname, "." + exe[exe.length - 1]);
        // file.originalname = name + "-" + Date.now();
        // var blobName = file.originalname;

        // console.log("blobName :-------",blobName);
        // return false
        for (var start = 0; start < file.buffer.length; start += streamLength, i++) {
            // var end = Math.min(start + streamLength, file.buffer.length);
            // console.log('end :', end);
            // return false

            // const blobService = azureStorage.createBlobService(azureStorageConfig.accountName, azureStorageConfig.accountKey); 
            // console.log("blobService :-------", blobService);


            // return 
            // const blob = blobService.createBlockBlobFromStream(azureStorageConfig.containerName, `${directoryPath}/${blobName}`, stream, streamLength, err => {
            //     if (err) {
            //         reject(err);
            //     } else {
            //         resolve({ filename: blobName, 
            //             originalname: file.originalname, 
            //             // size: streamLength.slice(start, end),
            //             size: streamLength, 
            //             path: `${azureStorageConfig.containerName}/${directoryPath}/${blobName}`,
            //             url: `${azureStorageConfig.blobURL}${azureStorageConfig.containerName}/${directoryPath}/${blobName}` });
               
            //         }
            // });
            // const blobService = azureStorage.createBlobService(azureStorageConfig.accountName, azureStorageConfig.accountKey); 

            // const blobStorage = {
            //     // azureStorageConfig:azureStorageConfig.accountName,
                // azureStorageConfig:azureStorageConfig.accountKey
                // blobService:blobService,
            // }

            // console.log("blobStorage :--------", blobStorage);
            
            promises.push(uploadLoadToAzureBlobStorage());
            
            // promises.push(blob);
            // promises.push(azureStorage.uploadBrowserDataToBlockBlob(blob));
        }

        Promise.all(promises).then(function (data) {

            console.log('upload file successfully : -------', data);

        }).catch(function (err) {
            res.send(err);
        })


        
            
        // async function uploadLoadToAzureBlobStorage(readableStream) {
        //     return new Promise((resolve, reject) => {
        //       var chunks = [];
        //       readableStream.on("data", data => {
        //         chunks.push(data.toString());
        //       });
        //       readableStream.on("end", () => {
        //         resolve(chunks.join(""));
        //       });
        //       readableStream.on("error", reject);
        //     });
        //   }




    });
 
};


// async function storeInMultiplePart(directoryPath, file) {
//     return new Promise((resolve, reject) => {

//         var blobName = getBlobName(file.originalname);
//         // console.log("sadasd name:------",blobName);
        
//         var stream = getStream(file.buffer);

//         // console.log("stream : ---------",stream);
//         // return false
//         // var stream = file.buffer;

//         var streamLength = Math.ceil(file.buffer.length / 3);

//         console.log("streamLength",streamLength);
//         //  return false
//         var promises = [];
//         var i = 1;
    

//     });
//   }


const getBlobName = originalName => {
    const identifier = Math.random().toString().replace(/0\./, ''); // remove "0." from start of string
    return `${identifier}-${originalName}`;
};

const fileUpload = async(req, res, next) => {
    // console.log("hello responce :--------");
    // return
    try {
        const image = await storeInMultiplePart('files', req.file); // images is a directory in the Azure container
        return res.json(image);
    } catch (error) {
        next(error);
    }
}

app.post('/upload/file', singleFileUpload.single('file'), fileUpload);

app.listen(port, () => console.log(`Azure Blob storage in Multiple part App listening on port ${port} !`))

module.exports = app;